package com.smkn40jakarta.hewan;

public class ikan {
    public static void ikan(){
        System.out.println("Mempunyai sisik");
        System.out.println("Berenang di air");
        System.out.println("Bernafas memakai insang");
        System.out.println("Memiliki ekor");
    }
}