package com.smkn40jakarta.hewan;

public class guguk {
    public static void guguk(){
        System.out.println("Berkaki 4");
        System.out.println("Berata 2");
        System.out.println("Berbulu");
        System.out.println("Berjalan maju");
        System.out.println("Berjalan mundur");
        System.out.println("Melihat ke kanan");
        System.out.println("Melihat ke kiri");
        System.out.println("Beranak");
    

    }
}
