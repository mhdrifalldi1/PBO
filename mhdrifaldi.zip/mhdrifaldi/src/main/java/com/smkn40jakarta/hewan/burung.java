package com.smkn40jakarta.hewan;

public class burung {
    public static void burung(){
        System.out.println("Bisa Terbang");
        System.out.println("Mempunyai 2 sayap");
        System.out.println("Mempunyai 2 mata");
        System.out.println("Mempunyai 2 kaki");
        System.out.println("Bisa makan");
        System.out.println("Bisa melihat");
        System.out.println("Melihat ke kanan");
        System.out.println("Melihat ke kiri");
        System.out.println("Bertelur");
    }
}