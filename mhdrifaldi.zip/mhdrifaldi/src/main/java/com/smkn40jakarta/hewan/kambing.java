package com.smkn40jakarta.hewan;

public class kambing {
public static void kambing(){
    System.out.println("Jumlah kaki kambing 4");
    System.out.println("Jumlah mata kambing 2");
    System.out.println("Berjalan maju");
    System.out.println("Berjalan mundur");
    System.out.println("Melihat ke kanan");
    System.out.println("Melihat ke kiri");
    System.out.println("Bisa Makan");
    System.out.println("Beranak");

    }
}
