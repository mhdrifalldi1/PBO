package com.smkn40jakarta;

import com.smkn40jakarta.hewan.burung;
import com.smkn40jakarta.hewan.guguk;
import com.smkn40jakarta.hewan.ikan;
import com.smkn40jakarta.hewan.kambing;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main(String[] args )
    {

        String namaDepan ="Muhammad";
        String namaBelakang ="Rifaldi hz";
        int absen =27;
        String sekolah ="Smkn 40 Jakarta";
        int umur =17;

        System.out.println("Nama     :"+namaDepan+" "+namaBelakang);
        System.out.println("Absen    :"+absen);
        System.out.println("Sekolah  :"+sekolah);
        System.out.println("Umur     :"+umur);

        System.out.println("\n\nkambing");
        kambing.kambing();
        System.out.println("\n\nguguk");
        guguk.guguk();
        System.out.println("\n\nburung");
        burung.burung();
        System.out.println("\n\nikan");
        ikan.ikan();



    
    }
}
